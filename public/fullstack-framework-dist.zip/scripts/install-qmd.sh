#!/usr/bin/env bash
set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'
info() { echo -e "${GREEN}[INFO]${NC} $*"; }
warn() { echo -e "${YELLOW}[WARN]${NC} $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*"; }

OS="$(uname -s | tr '[:upper:]' '[:lower:]')"
ARCH="$(uname -m)"
[[ $OS == linux* ]] && OS=linux || [[ $OS == darwin* ]] && OS=darwin || { error "Unsupported OS: $OS"; exit 1; }
[[ $ARCH == x86_64 ]] && ARCH=amd64 || [[ $ARCH == aarch64 || $ARCH == arm64 ]] && ARCH=arm64 || { error "Unsupported arch: $ARCH"; exit 1; }

if command -v qmd &>/dev/null; then info "QMD already installed"; exit 0; fi

if [[ $EUID -eq 0 ]]; then INSTALL_DIR="/usr/local/bin"; else INSTALL_DIR="${HOME}/.local/bin"; mkdir -p "$INSTALL_DIR"; fi

VERSION="v0.3.0"
URL="https://github.com/quantized/qmd/releases/download/${VERSION}/qmd-${OS}-${ARCH}"
info "Downloading QMD..."
TMPFILE="$(mktemp)"
if command -v curl &>/dev/null; then curl -fsSL -o "$TMPFILE" "$URL"
elif command -v wget &>/dev/null; then wget -qO "$TMPFILE" "$URL"
else error "Need curl or wget"; exit 1; fi
chmod +x "$TMPFILE"
mv "$TMPFILE" "$INSTALL_DIR/qmd"
info "Installed to $INSTALL_DIR/qmd"
[[ $INSTALL_DIR != "/usr/local/bin" && ":$PATH:" != *":$INSTALL_DIR:"* ]] && warn "Add $INSTALL_DIR to PATH"
$INSTALL_DIR/qmd version &>/dev/null || warn "Installation may have failed"
