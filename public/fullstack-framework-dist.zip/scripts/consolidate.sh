#!/usr/bin/env bash
set -euo pipefail

YESTERDAY=$(date -d "yesterday" +%Y-%m-%d)
LOG_DIR="${HOME}/.openclaw/logs/telegram"
MEMORY_DIR="${HOME}/.openclaw/memory"
NOTES_DIR="${MEMORY_DIR}/notes"
mkdir -p "$NOTES_DIR"

# Find logs
LOGS=()
if [[ -d "$LOG_DIR" ]]; then
  while IFS= read -r -d '' f; do LOGS+=("$f"); done < <(find "$LOG_DIR" -type f -name "*$YESTERDAY*" -print0 2>/dev/null)
fi

DAILY_NOTE="$NOTES_DIR/$YESTERDAY.md"
echo "## Consolidation $(date)" >> "$DAILY_NOTE"
echo "Found ${#LOGS[@]} logs." >> "$DAILY_NOTE"

# Simple extraction (placeholder)
if [[ ${#LOGS[@]} -gt 0 ]]; then
  TMP=$(mktemp)
  for f in "${LOGS[@]}"; do cat "$f" >> "$TMP"; done
  # Count lines as a naive metric
  LINES=$(wc -l < "$TMP")
  echo "Processed $LINES lines of chat." >> "$DAILY_NOTE"
  rm -f "$TMP"
fi

# Re-index if QMD present
if command -v qmd &>/dev/null; then
  qmd index "$MEMORY_DIR" >> /var/log/qmd-index.log 2>&1 || true
  echo "QMD index updated." >> "$DAILY_NOTE"
fi

echo "Consolidation complete."
