#!/usr/bin/env python3
"""Heuristic info extractor from chat logs (MVP placeholder)."""
import re, sys
from pathlib import Path

def extract(text: str) -> str:
    out = []
    for line in text.splitlines():
        if re.search(r"\b(TODO|FIXME|DECISION|NOTE)\b", line, re.I):
            out.append(line)
        if "@" in line and not line.strip().startswith("#"):
            out.append(line)
    return "\n".join(out)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: extract_important.py <chat_file>")
        sys.exit(1)
    print(extract(Path(sys.argv[1]).read_text()))
