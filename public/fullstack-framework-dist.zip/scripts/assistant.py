#!/usr/bin/env python3
import os
from pathlib import Path

def main():
    print("="*60)
    print("Full-Stack Framework Setup Assistant")
    print("="*60)

    home = Path.home()
    oc_dir = home / ".openclaw"
    oc_dir.mkdir(parents=True, exist_ok=True)

    # Questions
    use_qmd = input("Use QMD for memory? (Y/n): ").strip().lower() or "y"
    telegram_chat_id = input("Your Telegram chat ID (get from @userinfobot): ").strip()
    enable_heartbeat = input("Enable enhanced heartbeat? (Y/n): ").strip().lower() or "y"

    # Generate config
    conf = f"""# OpenClaw Configuration
memory.search_backend = "{"qmd" if use_qmd.startswith('y') else "default"}"
heartbeat.interval_minutes = 30
security.authenticated_chat_id = "{telegram_chat_id}"
"""
    conf_path = oc_dir / "openclaw.conf"
    conf_path.write_text(conf)
    print(f"Wrote config to {conf_path}")

    # Generate rules.md
    rules = f"""# Security Rules

Authenticated channels:
- Telegram chat ID: {telegram_chat_id}

Informational channels:
- Email, Twitter, web scraping

All financial operations require explicit confirmation via Telegram.
"""
    rules_path = oc_dir / "rules.md"
    rules_path.write_text(rules)
    print(f"Wrote rules to {rules_path}")

    # Copy templates
    this_dir = Path(__file__).resolve().parent
    tmpl_src = this_dir.parent / "templates"
    if tmpl_src.exists():
        dest = oc_dir / "templates"
        import shutil
        shutil.copytree(tmpl_src, dest, dirs_exist_ok=True)
        print(f"Copied templates to {dest}")

    print("\nNext steps:")
    print("1. Install QMD if selected: dist/scripts/install-qmd.sh")
    print("2. Run: python3 dist/scripts/configure-openclaw.py")
    print("3. Initialize memory: qmd index ~/.openclaw/memory")
    print("4. Add cron: 0 2 * * * dist/scripts/consolidate.sh")
    print("5. Restart OpenClaw")
    print("\nSetup complete. Adjust files as needed.")

if __name__ == "__main__":
    main()
