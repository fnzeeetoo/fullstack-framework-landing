#!/usr/bin/env python3
import os, shutil, subprocess
from pathlib import Path

def main():
    base_dir = Path(__file__).resolve().parents[2]  # dist/
    templates_dir = base_dir / "templates"
    home = Path.home()
    openclaw_dir = home / ".openclaw"
    memory_dir = openclaw_dir / "memory"

    print("Configuring OpenClaw to use QMD...")
    openclaw_dir.mkdir(parents=True, exist_ok=True)

    # Copy memory template
    mem_tmpl = templates_dir / "memory"
    if mem_tmpl.exists():
        if memory_dir.exists():
            for item in mem_tmpl.iterdir():
                dest = memory_dir / item.name
                if dest.exists():
                    print(f"  Skip existing {item.name}")
                else:
                    if item.is_dir():
                        shutil.copytree(item, dest)
                    else:
                        shutil.copy2(item, dest)
        else:
            shutil.copytree(mem_tmpl, memory_dir)

    # Copy rule snippets
    rules_d = openclaw_dir / "rules.d"
    rules_d.mkdir(parents=True, exist_ok=True)
    for snippet in templates_dir.joinpath("rules.d").glob("*"):
        shutil.copy2(snippet, rules_d / snippet.name)

    # Copy config templates for user reference
    user_templates = openclaw_dir / "templates"
    if user_templates.exists():
        shutil.rmtree(user_templates)
    shutil.copytree(templates_dir, user_templates)

    print("Configuration prepared. Next:")
    print("  1. Edit ~/.openclaw/rules.md (set chat ID)")
    print("  2. Run: qmd index ~/.openclaw/memory")
    print("  3. Restart OpenClaw")

if __name__ == "__main__":
    main()
