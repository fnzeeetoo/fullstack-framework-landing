# Full-Stack Framework for OpenClaw

A production-ready configuration package that implements best practices for memory management, heartbeat monitoring, security, and multi-threading in OpenClaw.

## Installation

### 1. Install QMD

```bash
curl -fsSL https://get.qmd.io | sh
```

QMD is a fast, local vector search system optimized for markdown knowledge bases.

### 2. Run the Setup Assistant

```bash
python3 dist/scripts/assistant.py
```

This creates your personalized configuration in `~/.openclaw/`.

### 3. Install the Memory Repository

```bash
mkdir -p ~/.openclaw/memory
cp -r dist/templates/memory/* ~/.openclaw/memory/
qmd index ~/.openclaw/memory
```

### 4. Add Cron Jobs

```bash
sudo cp dist/scripts/consolidate.sh /usr/local/bin/openclaw-consolidate
sudo chmod +x /usr/local/bin/openclaw-consolidate
# Add to crontab: 0 2 * * * /usr/local/bin/openclaw-consolidate >> /var/log/openclaw-consolidate.log 2>&1
```

### 5. Update Your HEARTBEAT.md

```bash
cp dist/templates/HEARTBEAT.md ~/.openclaw/HEARTBEAT.md
```

### 6. Configure Security Rules

```bash
cp dist/templates/rules.md ~/.openclaw/rules.md
```

Edit to set your authenticated Telegram chat ID.

### 7. Enable Multi-Threading

1. Create a new Telegram group with your bot
2. Set bot permissions: Groups ON, Privacy OFF
3. Each group spawns an isolated session

---

## AgentTrader Dashboard (Optional Add‑on)

The distribution includes an autonomous trading dashboard under `dashboard/`. It integrates with the Framework's heartbeat and provides:

- **Four strategies**: Contrarian, TBO Trend, TBT Divergence, Late Entry
- **Configuration UI**: Enable/disable strategies and adjust risk limits
- **Charts**: Equity curve via Recharts
- **Blotter**: Recent trades with P&L
- **Backtester**: CLI to run historical tests and generate reports

### Deploying the Dashboard

```bash
cd dist/dashboard
npm install
npm run dev   # or build and deploy to Vercel
```

For production, set environment variables (`NEXT_PUBLIC_STRIPE_PUBLIC_KEY`, `STRIPE_SECRET_KEY`, `WEBHOOK_SECRET`) if using Stripe integration.

Configuration files are in `config/strategies.yaml` and `config/risk.yaml`. Paper trading logs are written to `data/paper_trades/`.

See `dashboard/README.md` for full details.
