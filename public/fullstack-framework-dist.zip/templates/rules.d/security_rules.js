// Security Rules
// Enforce channel authentication

module.exports = {
  name: "Security Rules",
  handler: async (ctx) => {
    if (ctx.input.type === "command") {
      const source = ctx.input.source_channel;
      if (isInformational(source) && !ctx.input.overridden) {
        ctx.blocked = true;
        ctx.output = { reason: "Informational channel requires explicit override." };
      }
    }
  },
};

function isInformational(channel) {
  return ["email", "twitter", "web"].includes(channel);
}
