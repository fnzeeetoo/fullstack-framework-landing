// QMD Integration Rule
// Replace default memory search with QMD

module.exports = {
  name: "QMD Integration",
  description: "Use QMD for fast markdown search",
  handler: async (ctx) => {
    if (ctx.input.type === "memory_search") {
      const query = ctx.input.query;
      // Call qmd CLI: qmd search <query>
      // Return results as markdown snippets
      ctx.output = { results: [] }; // populated by QMD
    }
  },
};
