# Heartbeat Checklist

Run every 30 minutes.

- [ ] Check daily notes for open projects that should have running sessions
- [ ] Monitor long-running Codex sessions (restart if died, report if finished)
- [ ] Ensure all sessions use persistent storage (not /tmp)
- [ ] Notify when jobs complete or fail
- [ ] Scan for unusual activity (security)
