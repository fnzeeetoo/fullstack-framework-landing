# Daily Note - {date}

## Projects

- [ ] 

## Conversations

## Metrics
