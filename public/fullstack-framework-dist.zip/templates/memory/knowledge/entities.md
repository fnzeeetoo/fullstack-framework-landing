# Entities

People, companies, and their relationships.

## People

- Stephen (FreeThinkerInc) - collaborator, provides strategic direction.

## Businesses

- Full-Stack Framework - product in development.
